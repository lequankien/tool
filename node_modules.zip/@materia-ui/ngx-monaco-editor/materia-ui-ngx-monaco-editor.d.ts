/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="@materia-ui/ngx-monaco-editor" />
export * from './public_api';
