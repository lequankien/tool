

import org.apache.avro.Schema;
import org.apache.avro.SchemaBuilder;
import org.apache.avro.file.DataFileReader;
import org.apache.avro.file.DataFileWriter;
import org.apache.avro.generic.GenericData;
import org.apache.avro.generic.GenericDatumReader;
import org.apache.avro.generic.GenericDatumWriter;
import org.apache.avro.generic.GenericRecord;
import org.apache.avro.io.DatumReader;
import org.apache.avro.io.DatumWriter;

import java.io.File;
import java.io.IOException;
public class main {
    private static final File FILE = new File("C:\\Users\\KienLQ\\Downloads\\users.avro");
    public static void main(String[] args) throws Exception {

        long startTime = System.nanoTime();

        System.out.println("loading...");
        String text = "c,v,b,,n,b,,";
        final Schema schema = SchemaBuilder
                .record("user").doc("Ususario").namespace("example.avro")
                .fields()
                .name("name").doc("Nome").type().stringType().noDefault()
                .name("favorite_number").doc("Numero favorito").type().nullable().intType().noDefault()
                .name("favorite_color").doc("Cor favorita").type().nullable().stringType().noDefault()
                .endRecord();

        final GenericRecord user1 = new GenericData.Record(schema);
        user1.put("name", "Alyssa");
        user1.put("favorite_number", 256);
//         Leave favorite color null

        final GenericRecord user2 = new GenericData.Record(schema);
        user2.put("name", "LU");
        user2.put("favorite_number", 3);
        user2.put("favorite_color", "Blue");

        serialize(schema, user2);
        deserialize();

        deserialize(SchemaBuilder
                .record("user").doc("Ususario").namespace("example.avro")
                .fields()
                .name("razao_social").doc("Nome").aliases("name").type().stringType().noDefault()
                .name("favorite_number").doc("Numero favorito").type().nullable().intType().noDefault()
                .name("favorite_color").doc("Cor favorita").type().nullable().stringType().noDefault()
                .endRecord());
    }

    private static void serialize(final Schema schema, final GenericRecord... users) throws IOException {
        // Serialize users to disk
        final DatumWriter<GenericRecord> writer = new GenericDatumWriter<>(schema);
        try (DataFileWriter<GenericRecord> fileWriter = new DataFileWriter<>(writer)) {
            fileWriter.create(schema, FILE);
            for (GenericRecord user : users) {
                fileWriter.append(user);
            }
        }
    }

    private static void deserialize() throws IOException {
        final DatumReader<GenericRecord> reader = new GenericDatumReader<>();
        final DataFileReader<GenericRecord> dataFileReader = new DataFileReader<>(FILE, reader);

        while (dataFileReader.hasNext()) {
            final GenericRecord record = dataFileReader.next();
            final Schema schema = record.getSchema();
            System.out.println("========== No Schema ==========");
            System.out.println("Schema para " + schema.getDoc());
            // System.out.println(schema.toString(true));
            System.out.println();
            schema.getFields().forEach(f -> {
                System.out.println(">>> " + f.doc() + ": " + record.get(f.name()));
            });
        }
    }

    private static void deserialize(final Schema schema) throws IOException {
        final DatumReader<GenericRecord> reader = new GenericDatumReader<>(schema);
        final DataFileReader<GenericRecord> dataFileReader = new DataFileReader<>(FILE, reader);

        while (dataFileReader.hasNext()) {
            final GenericRecord record = dataFileReader.next();
            System.out.println(">>>>>>>>>> Schema >>>>>>>>>>");
            System.out.println("Schema para " + schema.getDoc());
            System.out.println();
            schema.getFields().forEach(f -> {
                System.out.println(">>> " + f.doc() + ": " + record.get(f.name()));
            });
        }
    }
}

